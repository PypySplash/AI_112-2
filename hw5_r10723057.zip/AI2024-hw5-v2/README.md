# Homework 5

請改一下下面這行程式碼的路徑，改為自己電腦上的路徑即可執行：
python pacman.py --eval --eval_model_path "/Users/huangyuanyu/Documents/Projects/AI_112-2/AI2024-hw5-v2/submissions/pacma_dqn.pt"

## Install Necessary Packages
conda create -n hw5 python=3.11 -y
conda activate hw5
pip install -r requirements.txt